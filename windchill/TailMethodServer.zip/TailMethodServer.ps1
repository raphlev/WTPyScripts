<#
.SYNOPSIS
	 Open and tail Windchill Method Server logs.
	
.PARAMETER WT_HOME
	Optional: Windchill Home directory. If the parameter is not set and WT_HOME environment variable is defined, 
	WT_HOME environment variable is read. Otherwise the script will fail.

.DESCRIPTION
	Invocation (or Windows shortcut command) example:
		powershell.exe C:\Users\Administrator\Documents\TailMethodServer.ps1 -WT_HOME D:\PTC\Windchill_11.0\Windchill
	
#>
param (
    [string]$wt_home = $ENV:WT_HOME
)

# Expected number of MS log to open
$num_ms = 0

# MS logs already opened
$opened_log_pids = @()

$show_wait_msg = 1

# Check WT_HOME input
if ( $wt_home -eq '' -or ! (Test-Path -Path $wt_home )) {
	Write-Error "Invalid WT_HOME input, exiting"
	exit 1
}

# Calculate the number of expected MS
$ms_services = Select-String -Path "$wt_home\codebase\wt.properties" "wt.manager.monitor.services=(.*)$" | select -Expand Matches | % { $_.groups[1].value }

Echo "Expected MS services: $ms_services"


$ms_services.Split(" ") | % {
	$num_proc = Select-String -Path "$wt_home\codebase\wt.properties" ("wt.manager.monitor.start."+ $_ +"=(.*)$") | select -Expand Matches | % { $_.groups[1].value }
	if ([string]::IsNullOrEmpty($num_proc)) {
		  $num_proc = 1 ;
	}
  Echo "Expected Number of services for $_ : $num_proc"
  Echo "Total Number of expected MS: $num_ms"
	$num_ms += $num_proc
}

Echo "Total Number of expected MS: $num_ms"

# Get Server Manager PID
$sm_proc = Get-CimInstance Win32_Process -Filter "name ='java.exe' AND CommandLine Like '%wt.manager.ServerManagerMain%'"

if ([string]::IsNullOrWhiteSpace($sm_proc)) {
	Write-Error "No Windchill Server Manager running."
	Pause
	exit 1
}

# Loop until all MS have started
while ($opened_log_pids.length -lt $num_ms) {
	# Get MS PIDs as child process od SMgr
	Get-CimInstance Win32_Process -Filter "name ='java.exe' AND ParentProcessId = $($sm_proc.ProcessId)" | % {
		$ms_pid = $_.ProcessId
		
		Echo "Server Manager (PID $($sm_proc.ProcessId) ) Child MS process: $ms_pid"
		Echo "Opened MS PIDs: $opened_log_pids"
		
		# Get MS logs file for this MS PID
		Get-ChildItem -path $wt_home\logs\* -Include *MethodServer*"$ms_pid"*log4j.log | Sort-Object LastAccessTime -Descending | Select-Object -First 1 | % {
			$ms_log_file = $_
			
			if ( $opened_log_pids -notcontains $ms_pid) {
				Echo "Tailing: $ms_log_file"
				start powershell -ArgumentList '-Command',("& { `$Host.UI.RawUI.WindowTitle = '$($ms_log_file.Name)' ; Get-Content $ms_log_file -Tail 500 -Wait } ")
				$opened_log_pids += $ms_pid
				$show_wait_msg = 1
			}
		}
	}
	
	$remaining = $num_ms - $opened_log_pids.length
	if ($show_wait_msg -and $remaining -gt 0) {
		echo "Waiting $remaining remaining Method servers to start ..."
		$show_wait_msg = 0
	}

}

echo "All of $($opened_log_pids.length) Method servers logs are opened."
